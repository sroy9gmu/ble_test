
package com.example.ble_test

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries
import com.punchthrough.blestarterappandroid.ScanResultAdapter
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.alert
import timber.log.Timber
import timber.log.Timber.DebugTree
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.time.LocalDateTime
import java.util.*
import android.bluetooth.BluetoothGattCharacteristic.*


private const val ENABLE_BLUETOOTH_REQUEST_CODE = 1
private const val LOCATION_PERMISSION_REQUEST_CODE = 2
private const val MAXIMUM_NUMBER_SAMPLES = 100
private const val KEY = "sample index"
private const val VALUE1 = "pulse signal"
private const val VALUE2 = "body temperature"

@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
class MainActivity(var pulseCount: Int = 1, var tempCount: Int = 1) : AppCompatActivity() {
    lateinit var gatt_g: BluetoothGatt
    lateinit var bpm: TextView;
    lateinit var mycollection1: String
    lateinit var mycollection2: String
    private var num_of_samples: Int = 0
    //private val compareByValue: Comparator<BluetoothGattCharacteristic> = compareBy { it.getIntValue(FORMAT_UINT16, 0) }

    @RequiresApi(Build.VERSION_CODES.N)
    //private val queue_g = PriorityQueue<BluetoothGattCharacteristic>(compareByValue)

    // creating a variable
    // for our graph view.
    lateinit var graphView: GraphView

    // Access a Cloud Firestore instance from your Activity
    private val db = Firebase.firestore

    private val SERVICE_UUID = UUID.fromString("8da11f6d-0a78-4c3a-8a83-941f7c1d064b")
    private val PULSE_UUID = UUID.fromString("3b0ef782-9b04-4fef-a3e8-c44f10f0f661")
    private val TEMP_UUID = UUID.fromString("6fcf1abb-a08e-4dae-a0ad-8b6d65ba27cb")

    private val bluetoothAdapter: BluetoothAdapter by lazy {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothManager.adapter
    }

    private val bleScanner by lazy {
        bluetoothAdapter.bluetoothLeScanner
    }

    private val scanSettings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

    private var isScanning = false
        set(value) {
            field = value
            val my_scan_button: Button = findViewById(R.id.scan_button)
            runOnUiThread { my_scan_button.text = if (value) "STOP SCAN" else "START SCAN" }
        }

    private var isWaiting = false
        set(value) {
            field = value
            val poll_button: Button = findViewById(R.id.button)
            val prev = poll_button.text
            runOnUiThread { poll_button.text = if (value) prev else "START POLLING" }
        }

    private val scanResults = mutableListOf<ScanResult>()

    private val scanResultAdapter: ScanResultAdapter by lazy {
        ScanResultAdapter(scanResults) { result ->
            if (isScanning) {
                stopBleScan()
            }
            with(result.device) {
                Timber.w("Connecting to $address")
                connectGatt(this@MainActivity, false, gattCallback)
                val my_poll_button: Button = findViewById(R.id.button)
                my_poll_button.text = "PLEASE WAIT"
                isWaiting = true
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val deviceAddress = gatt.device.address
            gatt_g = gatt
            Timber.w("Debug: Global gatt assigned with device address ${gatt_g.device.address}")
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Timber.w("Successfully connected to $deviceAddress")
                    Handler(Looper.getMainLooper()).post {
                        gatt?.discoverServices()
                    }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Timber.w("Successfully disconnected from $deviceAddress")
                    gatt.close()
                }
            } else {
                Timber.w("Error $status encountered for $deviceAddress! Disconnecting...")
                gatt.close()
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            gatt_g = gatt
            with(gatt) {
                Timber.w("Discovered ${services.size} services for ${device.address}")
                printGattTable()
                isWaiting = false
            }
        }

        @RequiresApi(Build.VERSION_CODES.O)
        override fun onCharacteristicRead(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
        ) {
            with(characteristic) {
                when (status) {
                    BluetoothGatt.GATT_SUCCESS -> {
                        val myByteArray: ByteArray = characteristic.getValue()
                        val bb: ByteBuffer = ByteBuffer.wrap(myByteArray)
                        bb.order(ByteOrder.LITTLE_ENDIAN)
                        val tmp: Int = bb.getInt()

                        if (characteristic.getUuid().equals(PULSE_UUID)) {
                            Timber.i("Debug: Pulse signal value $pulseCount: $tmp")
                            // Create a new reading
                            val reading = hashMapOf(
                                    KEY to pulseCount,
                                    VALUE1 to tmp
                            )
                            // Add a new document with a generated ID
                            if (pulseCount == 1) {
                                mycollection1 = VALUE1 + LocalDateTime.now().toString()
                            }

                            db.collection(mycollection1)
                                    .add(reading)
                                    .addOnSuccessListener { documentReference ->
                                        Timber.i("Debug: Pulse DocumentSnapshot added with ID: ${documentReference.id}")
                                    }
                                    .addOnFailureListener { e ->
                                        Timber.w("Debug: Error adding pulse document: $e")
                                    }

                            if (pulseCount == num_of_samples) {
                                db.collection(mycollection1)
                                        .get()
                                        .addOnSuccessListener { documents ->
                                            for (document in documents) {
                                                Timber.d("Debug: Pulse ${document.id} => ${document.data}")
                                            }
                                        }
                                        .addOnFailureListener { exception ->
                                            Timber.w("Debug: Error getting pulse documents: ${exception}")
                                        }
                            }

                            pulseCount++
                        } else if (characteristic.getUuid().equals(TEMP_UUID)) {
                            Timber.i("Debug: Temperature value $tempCount: $tmp")
                            // Create a new user with a first and last name
                            val reading = hashMapOf(
                                    KEY to tempCount,
                                    VALUE2 to tmp
                            )

                            // Add a new document with a generated ID
                            if (tempCount == 1) {
                                mycollection2 = VALUE2 + LocalDateTime.now().toString()
                            }

                            db.collection(mycollection2)
                                    .add(reading)
                                    .addOnSuccessListener { documentReference ->
                                        Timber.i("Debug: Temperature DocumentSnapshot added with ID: ${documentReference.id}")
                                    }
                                    .addOnFailureListener { e ->
                                        Timber.w("Debug: Error adding temperature document: $e")
                                    }

                            if (tempCount == num_of_samples) {
                                db.collection(mycollection2)
                                        .get()
                                        .addOnSuccessListener { documents ->
                                            for (document in documents) {
                                                Timber.d("Debug: Temperature ${document.id} => ${document.data}")
                                            }
                                        }
                                        .addOnFailureListener { exception ->
                                            Timber.w("Debug: Error getting temperature documents: ${exception}")
                                        }
                            }

                            tempCount++
                        } else {

                        }

                        //bpm.setText(tmp.toString()) TODO
                    }
                    BluetoothGatt.GATT_READ_NOT_PERMITTED -> {
                        Timber.e("Read not permitted for $uuid!")
                    }
                    else -> {
                        Timber.e("Characteristic read failed for $uuid, error: $status")
                    }
                }
            }
        }
    }

    fun ByteArray.toHexString(): String =
            joinToString(separator = " ", prefix = "0x") { String.format("%02X", it) }

    override fun onResume() {
        super.onResume()
        if (!bluetoothAdapter.isEnabled) {
            promptEnableBluetooth()
        }
    }

    private fun BluetoothGatt.printGattTable() {
        if (services.isEmpty()) {
            Timber.i("No service and characteristic available, call discoverServices() first?")
            return
        }

        services.forEach { service ->
            val characteristicsTable = service.characteristics.joinToString(
                    separator = "\n|--",
                    prefix = "|--"
            ) { it.uuid.toString() }
            Timber.i("\nService ${service.uuid}\nCharacteristics:\n$characteristicsTable"
            )
        }
    }

    private fun promptEnableBluetooth() {
        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, ENABLE_BLUETOOTH_REQUEST_CODE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            ENABLE_BLUETOOTH_REQUEST_CODE -> {
                if (resultCode != Activity.RESULT_OK) {
                    promptEnableBluetooth()
                }
            }
        }
    }

    private val isLocationPermissionGranted
        get() = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)

    fun Context.hasPermission(permissionType: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permissionType) ==
                PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        graphView = findViewById<View>(R.id.graph) as GraphView
        val series = LineGraphSeries(arrayOf<DataPoint>(
                DataPoint(0.toDouble(), 1.toDouble()),
                DataPoint(1.toDouble(), 5.toDouble()),
                DataPoint(2.toDouble(), 3.toDouble()),
                DataPoint(3.toDouble(), 2.toDouble()),
                DataPoint(4.toDouble(), 6.toDouble())
        ))
        graphView.addSeries(series)

        // This will initialise Timber
        if (BuildConfig.DEBUG) {
            Timber.plant(DebugTree())
        }

        bpm = findViewById(R.id.textView8)

        val my_poll_button: Button = findViewById(R.id.button)
        my_poll_button.text = "TARGET DISCONNECTED"

        val my_scan_button: Button = findViewById(R.id.scan_button)
        my_scan_button.setOnClickListener {
            if (isScanning) {
                stopBleScan()
            } else {
                startBleScan()
            }
        }
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        scan_results_recycler_view.apply {
            adapter = scanResultAdapter
            layoutManager = LinearLayoutManager(
                    this@MainActivity,
                    RecyclerView.VERTICAL,
                    false
            )
            isNestedScrollingEnabled = false
        }

        val animator = scan_results_recycler_view.itemAnimator
        if (animator is SimpleItemAnimator) {
            animator.supportsChangeAnimations = false
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val indexQuery = scanResults.indexOfFirst { it.device.address == result.device.address }
            if (indexQuery != -1) { // A scan result already exists with the same address
                scanResults[indexQuery] = result
                scanResultAdapter.notifyItemChanged(indexQuery)
            } else {
                with(result.device) {
                    Timber.i("Found BLE device! Name: ${name ?: "Unnamed"}, address: $address")
                }
                scanResults.add(result)
                scanResultAdapter.notifyItemInserted(scanResults.size - 1)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            Timber.e("onScanFailed: code $errorCode")
        }
    }

    private fun startBleScan() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !isLocationPermissionGranted) {
            requestLocationPermission()
        }
        else {
            scanResults.clear()
            scanResultAdapter.notifyDataSetChanged()
            bleScanner.startScan(null, scanSettings, scanCallback)
            isScanning = true
            bleScanner.startScan(null, scanSettings, scanCallback)
            isScanning = true
        }
    }

    private fun requestLocationPermission() {
        if (isLocationPermissionGranted) {
            return
        }
        runOnUiThread {
            alert {
                title = "Location permission required"
                message = "Starting from Android M (6.0), the system requires apps to be granted " +
                        "location access in order to scan for BLE devices."
                isCancelable = false
                positiveButton(android.R.string.ok) {
                    requestPermission(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            LOCATION_PERMISSION_REQUEST_CODE
                    )
                }
            }.show()
        }
    }

    private fun Activity.requestPermission(permission: String, requestCode: Int) {
        ActivityCompat.requestPermissions(this, arrayOf(permission), requestCode)
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.firstOrNull() == PackageManager.PERMISSION_DENIED) {
                    requestLocationPermission()
                } else {
                    startBleScan()
                }
            }
        }
    }

    private fun stopBleScan() {
        bleScanner.stopScan(scanCallback)
        isScanning = false
    }

    /** Called when the user taps the Start Polling button */
    @RequiresApi(Build.VERSION_CODES.N)
    fun startPolling(view: View) {
        // Do something in response to button
        // Consider connection setup as complete here
        if (isWaiting == true) {
            return
        }

        num_of_samples = Integer.parseInt(editTextNumber.getText().toString());
        if (num_of_samples == 0){
            num_of_samples = MAXIMUM_NUMBER_SAMPLES
        }

        /*while (pulseCount < num_of_samples || tempCount < num_of_samples) {
            queue_g.add(pulseChar_g);
            queue_g.add(tempChar_g);
        }*/
        while (tempCount < num_of_samples) {
            val tempChar = gatt_g.getService(SERVICE_UUID).getCharacteristic(TEMP_UUID)
            gatt_g.readCharacteristic(tempChar)
        }
        /*while (pulseCount < num_of_samples) {
            val pulseChar = gatt_g.getService(SERVICE_UUID).getCharacteristic(PULSE_UUID)
            gatt_g.readCharacteristic(pulseChar)
        }*/
    }
}
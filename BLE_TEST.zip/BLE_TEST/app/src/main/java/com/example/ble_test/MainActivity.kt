package com.example.ble_test

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


    }

    /** Called when the user taps the Start button */
    fun showResults(view: View) {
        // Do something in response to button
        val textView = findViewById<TextView>(R.id.textView).apply {
            text = "45.6"
        }
        val textView3 = findViewById<TextView>(R.id.textView3).apply {
            text = "g"
        }
    }

    /** Called when the user taps the End button */
    fun removeResults(view: View) {
        // Do something in response to button
        val textView = findViewById<TextView>(R.id.textView).apply {
            text = ""
        }
        val textView3 = findViewById<TextView>(R.id.textView3).apply {
            text = ""
        }
    }
}